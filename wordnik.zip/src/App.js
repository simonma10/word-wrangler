import React, { Component, Fragment } from 'react';
import './App.css';
import {getWord, wordOperations} from './wordnik-api';
import {getUrl, performGetRequest, ACTION_GET_DEFINITION, LOCAL} from './oxford-api';
import SearchForm from './SearchForm';
import SearchTypeSelector from './SearchTypeSelector';

class App extends Component {

  constructor(props) {
    super(props);
    this.handleSearchSubmit = this.handleSearchSubmit.bind(this);
    let options = [];
    wordOperations.forEach((item)=>{options.push(item.op)});
    this.handleSearchTypeSelectChange = this.handleSearchTypeSelectChange.bind(this);
    this.state = {
      response:[],
      searchTerm: '',
      options: options,
      selectedOperation: options[0]
    };   
  }

  async handleSearchSubmit(searchTerm) {
    let response = await getWord(searchTerm, this.state.selectedOperation);
    console.log('response: ', response);
    // let hyphenation = await getWord(searchTerm, 'hyphenation');
    let url = getUrl(searchTerm, ACTION_GET_DEFINITION);
    console.log('url', url);
    let res = performGetRequest(LOCAL);
    console.log('response', res);
    this.setState({searchTerm, response});
  }

  handleSearchTypeSelectChange(value){
    this.setState({...this.state, selectedOperation: value});
  }

  renderResponse(response){
    //let wordOperationsItem = wordOperations.find((item)=> {return item.op === this.state.selectedOperation})
    //return wordOperationsItem.render(response);
    switch(this.state.selectedOperation){
      case 'definitions':
        return this.renderDefinitions(response);
      case 'pronunciations':
        return this.renderPronunciation(response);
      case 'audio':
        return this.renderAudio(response);
      default:
        return (
        <div>
          <p>Not yet implemented. Check console for raw response details.</p>
        </div>)
    }
  }

  renderDefinitions(response){
    if(response === []) { return(<p>Loading...</p>) }
    const list = response.map((item, index) => 
      <li key={index}>{item.text}</li>
    )
    return (
      <div>
        {list.length > 0 && <h4>Definitions</h4>}
        <ul>{list}</ul>
      </div>
      
    )
  }

  renderPronunciation(response){
    const list = response.map((item, index) => 
      <li key={index}><strong>Type: </strong>{item.rawType||'unknown'}, <strong>Pronunciation: </strong>{item.raw||'unknown'}</li>
    )
    return (
      <div>
        {list.length > 0 && <h4>Pronunciations</h4>}
        <ul>{list}</ul>
      </div>
      
    )
  }

  renderAudio(response){
    const list = response.map((item, index) => 
      <li key={index}><a type="audio/mpeg" target="frame" href={item.fileUrl||'#'}>{item.attributionText||'attribution unknown'}</a></li>
    )
    return (
      <div>
        {list.length > 0 && 
        <Fragment>
          <h4>Audio</h4>
          <ul>{list}</ul>
          <div className="audioFrame">
            <iframe title="Audio" name="frame" height="180px" width="400px"></iframe>
          </div>
        </Fragment>
        }
      </div>
    )
  }

  render() {
    let response = this.state.response;
    let optionsList = this.state.options;
    return (
      <div>
        <div className="Header">
          <SearchTypeSelector 
            options={optionsList}
            onChange={this.handleSearchTypeSelectChange}
            value={this.state.selectedOperation}
          />
          <SearchForm onSubmit={this.handleSearchSubmit} />
        </div>
        <div className="Results">
          <h2>{this.state.searchTerm}</h2>
          {this.renderResponse(response)}
        </div>
      </div>
    );
  }
}

export default App;
