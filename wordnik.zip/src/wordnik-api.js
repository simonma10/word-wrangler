import React from 'react';
import axios from 'axios';

/**
|--------------------------------------------------
| API Connection data and data about routes
|--------------------------------------------------
*/
const BASE_URL = 'http://api.wordnik.com/v4';
const API_KEY = '888bcca6c3b71d33bc00d082ffb097163629728dd078e8ca6';
const API_ROUTE_WORDS = '/word.json';
//const API_ROUTE_RAND = '/randomWord';

/**
|--------------------------------------------------
| For each route, define an array of operations
| that has a description, and a basic function for
| rendering the response.
|--------------------------------------------------
*/
export const wordOperations = [
    {op: 'word',
     desc: 'Given a word as a string, returns the WordObject that represents it',
     render: function(response){return <p>Word Operation|response={response ? response : 'none'}</p>}},
    {op: 'audio',
     desc: 'Fetches audio metadata for a word',
     render: function(response){return <p>Audio Operation|response={response ? response : 'none'}</p>}},
    {op: 'definitions',
     desc: 'Return definitions for a word',
     render: function(response){return <p>Definitions|response={response ? response : 'none'}</p>}},
    {op: 'etymologies',
     desc: 'Fetches etymology data',
     render: function(response){return <p>Etymologies Operation|response={response ? response : 'none'}</p>}},
    {op: 'examples', 
    desc: 'Returns examples for a word',
    render: function(response){return <p>Examples Operation|response={response ? response : 'none'}</p>}},
    {op: 'frequency',
     desc: 'Returns word usage over time',
     render: function(response){return <p>Frequency Operation|response={response ? response : 'none'}</p>}},
    {op: 'hyphenation',
     desc: 'Returns syllable information for a word',
     render: function(response){return <p>Hyphenation Operation|response={response ? response : 'none'}</p>}},
    {op: 'phrases',
     desc: 'Fetches bi-gram phrases for a word',
     render: function(response){return <p>Word Operation|response={response ? response : 'none'}</p>}},
    {op: 'pronunciations',
     desc: 'Returns text pronunciations for a given word',
     render: function(response){return <p>Pronunciations Operation|response={response ? response : 'none'}</p>}},
    {op: 'relatedWords',
     desc: 'Given a word as a string, returns relationships from the Word Graph',
     render: function(response){return <p>relatedWords Operation|response={response ? response : 'none'}</p>}},
    {op: 'scrabbleScore',
     desc: 'Returns the Scrabble score for a word',
     render: function(response){return <p>scrabbleScore Operation|response={response ? response : 'none'}</p>}},
    {op: 'topExample',
     desc: 'Returns a top example for a word',
     render: function(response){return <p>topExample Operation|response={response ? response : 'none'}</p>}}
]

export function simpleGetRequest(url){
    console.log('simpleGetRequest on URL', url);

    return axios.get(url)
        .then(function (response){
            console.log('response', response);
            //dispatch({ type: actionType, payload: response});
            return response;
        })
        .catch(function (error){
            console.log(error);
            //dispatch({ type: 'ERROR', payload: error});
            return error;
        })
}

export function getWord(word, operation){
    console.log('getWord: ', word, ', operation: ', operation );
    //validation
    let validation = ''
    wordOperations.forEach((item)=>{
        if(item.op === operation){
            validation = item.desc;
        }
    });
    if (validation === '') {
        return('Error - invalid operation: ' + operation);
    }

    let url = BASE_URL + API_ROUTE_WORDS + '/' + word + '/' + operation + '?api_key=' + API_KEY;
    console.log(url);
    return axios.get(url)
        .then(function (response){
            //console.log('response', response);
            return response.data;
        })
        .catch(function (error){
            //console.log(error);
            return ['Error', error];
        })
}

export function reduxGet(url, actionType ){
    console.log('http get on url ', url, ' with redux action', actionType);

    return dispatch => axios.get(url,{})
        .then(function (response){
            console.log('response', response);
            dispatch({ type: actionType, payload: response});
            //return response;
        })
        .catch(function (error){
            console.log(error);
            dispatch({ type: 'ERROR', payload: error});
            //return error;
        })
}

