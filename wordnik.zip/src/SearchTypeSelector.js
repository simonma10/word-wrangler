import React, { Component } from 'react';
import './App.css';

class SearchTypeSelector extends Component {

    constructor(props){
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.select = React.createRef();
        this.state = {
            options: this.props.options || ['']
        }
    }

    handleChange(event){
        this.props.onChange(event.target.value)
    }

    getOptions(){
        const options = this.state.options.map((option, index) => 
            <option key={index} value={option}>{option}</option>
        );
        return options;
    }

    render(){
        let state = this.state;

        return(
            <div className="Search">
                <span className="Search-items">Category:</span>

                <select
                    ref={this.select} 
                    value={this.props.value}
                    onChange={this.handleChange}
                >
                {this.getOptions()}
                </select>
            </div>
        )
    }
}

export default SearchTypeSelector;