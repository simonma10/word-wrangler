
const keys = {
    OED_BASE_URL: 'https://od-api.oxforddictionaries.com/api/v1',
    OED_APP_ID:'c383587a',
    OED_APP_KEY:'95368b10bc2e607c6b68855ffb202afa',
    WORDNIK_BASE_URL:'http://api.wordnik.com/v4',
    WORDNIK_API_KEY:'888bcca6c3b71d33bc00d082ffb097163629728dd078e8ca6'
}


module.exports = keys;