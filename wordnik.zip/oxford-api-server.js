var express = require('express');
var router = express.Router();
var axios = require('axios');
var apiKeys = require('./keys');

const app_id = apiKeys.OED_APP_ID;
const app_key = apiKeys.OED_APP_KEY;
const base_url = apiKeys.OED_BASE_URL;

// middleware that is specific to this router
router.use(function timeLog (req, res, next) {
  console.log('>>> Oxford API Server <<< Time: ', Date.now())
  next()
})
// define the home page route
router.get('/', function (req, res) {
  res.send('Valid routes:\n/definitions/{word}\n/synonyms/{word}\n/antonyms/{word}')
})

// definition
router.get('/definitions/:word', function (req, res) {
    let url = base_url + '/entries/en/' + req.params["word"]
    callApi(url, res);
})

// synonyms
router.get('/synonyms/:word', function (req, res) {
    let url = base_url + '/entries/en/' + req.params["word"] + '/synonyms'
    callApi(url, res);
})

// antonyms
router.get('/antonyms/:word', function (req, res) {
    let url = base_url + '/entries/en/' + req.params["word"] + '/antonyms'
    callApi(url, res);
})


function callApi(url, res){
    axios.get(url, {
        headers: {
          app_id: app_id,
          app_key: app_key
        }
      })
           .then(function (response){
               res.send(response.data.results);
           })
           .catch(function (error){
               console.log(error);
               res.send(error);
           })
}

module.exports = router