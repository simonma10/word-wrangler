var express = require('express');
var path = require('path');
var cors = require('cors');
var fs = require("fs");
var axios = require("axios");

var apiKeys = require("./keys");
var oxford = require("./oxford-api-server");

var app = express();
var router = express.Router();

app.use(express.static('build'));
app.use(cors());

app.get('/', function (req, res) {
    res.sendFile("/build/index.html" );
 })

 app.get('/request', function(req, res) {
   //console.log('request...', req);
   //let r = BASE_URL + '/entries/en/molecule'
   let r = req.params['targetUrl'];
   
   axios.get(r, {
     headers: {
       app_id: apiKeys.OED_APP_ID,
       app_key: apiKeys.OED_APP_KEY
     }
   })
        .then(function (response){
            //console.log('data', response.data.results);
            res.send(response.data);
        })
        .catch(function (error){
            console.log(error);
            res.send(error);
        })
 })

app.use('/oxford', oxford);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

var server = app.listen(8080, function () {
    var host = server.address().address
    var port = server.address().port
    
    console.log("Example app listening at http://%s:%s", host, port)
 })


module.exports = app;
